$_ Thanks for Boosting.


You need [node.js](https://nodejs.org/en/download/) installed first!
Step 1: Put your codes and HTTP/Socks5 proxies in the folder (You can remove codes.txt and proxies.txt)
Step 2: Open index.js in a text editor. (You can skip step 2, step 3 and step 4 if you want to generate it automatically)
Step 3: Change codes.txt and proxies.txt to what your file names are for those. (You can also set options!)
Step 4: Save the file
Step 5: Open Start.bat
Step 6: It will now generate and check the fucking NITRO codes!

NOTE : Keep petience or YOU WON'T GET A FUCKING SINGLE NITROOO CODEEE.

AND THANKS FOR PURCHASING!!

- Have a good day MF